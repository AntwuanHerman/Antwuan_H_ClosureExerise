//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport
var num1 = 6
var num2 = 9
let multiplyInts = {(num1: Int, num2: Int) -> Int in
    return num1 * num2
}
print(multiplyInts(num1, num2))

